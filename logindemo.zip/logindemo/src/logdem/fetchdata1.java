/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package logdem;
import connect.connectdb;
import java.util.*;
import java.sql.*;


/**
 *
 * @author hp
 */
public class fetchdata1 {
   
    public Vector getuser()throws Exception
    {
        Vector<Object>userVector=new Vector<Object>(3);
        Connection conn=connectdb.createconnection();
        PreparedStatement pre=conn.prepareStatement("select * from record");
        ResultSet rs=pre.executeQuery();
        while(rs.next())
        {
            Vector<Object>user=new Vector<Object>();
            user.add(rs.getString(1));
            user.add(rs.getString(2));
            user.add(rs.getString(3));
            user.add(rs.getString(4));
            user.add(rs.getString(5));
            user.add(rs.getString(6));
         
            userVector.add(user);
        }
        if(conn!=null)
            conn.close();
        return userVector;
    
    }
    
    public Vector getpost()throws Exception
    {
        Vector<Object>postVector=new Vector<Object>(3);
        Connection conn=connectdb.createconnection();
        PreparedStatement pre=conn.prepareStatement("select * from post");
        ResultSet rs=pre.executeQuery();
        while(rs.next())
        {
            Vector<Object>post=new Vector<Object>();
            post.add(rs.getString(1));
            post.add(rs.getString(2));
            post.add(rs.getInt(3));
            
         
            postVector.add(post);
        }
        if(conn!=null)
            conn.close();
        return postVector;
       }
    public Vector getact()throws Exception
    {
        Vector<Object>actVector=new Vector<Object>(3);
        Connection conn=connectdb.createconnection();
        PreparedStatement pre=conn.prepareStatement("select * from act");
        ResultSet rs=pre.executeQuery();
        while(rs.next())
        {
            Vector<Object>act=new Vector<Object>();
            act.add(rs.getString(1));
            act.add(rs.getString(2));
        
       
            actVector.add(act);
        }
        if(conn!=null)
            conn.close();
        return actVector;
       }
    
    public Vector getcom()throws Exception
    {
         Vector<Object>comVector=new Vector<Object>(3);
        Connection conn=connectdb.createconnection();
        PreparedStatement pre=conn.prepareStatement("select * from postcom");
        ResultSet rs=pre.executeQuery();
        while(rs.next())
        {
            Vector<Object>com=new Vector<Object>();
            com.add(rs.getString(1));
            com.add(rs.getString(2));
            com.add(rs.getString(3));
           
         
            comVector.add(com);
        }
        if(conn!=null)
            conn.close();
        return comVector;
    
    }
    
    public Vector getfbusers()throws Exception
    {
         Vector<Object>uuVector=new Vector<Object>(3);
        Connection conn=connectdb.createconnection();
        PreparedStatement pre=conn.prepareStatement("select * from record");
        ResultSet rs=pre.executeQuery();
        while(rs.next())
        {
            Vector<Object>uu=new Vector<Object>();
            if(!((rs.getString(6)).equals(log.name)))
            {
            
            uu.add(rs.getString(1));
            uu.add(rs.getString(3));
            uu.add(rs.getString(6));
            }
            
           
         
            uuVector.add(uu);
        }
        if(conn!=null)
            conn.close();
        return uuVector;
    }
    
}
