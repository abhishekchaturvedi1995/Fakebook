/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package logdem;

import connect.connectdb;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author hppc
 */
public class DropTables {
    public static void main(String args[]) throws SQLException{
        Connection c=null;
        Statement stmt=null;
        String str="";
        try{
            c=connectdb.createconnection();
            stmt=c.createStatement();
        }
        catch(SQLException se){
            System.out.println("error"+se);
        }
        catch(ClassNotFoundException ex){
            System.out.println("found error......"+ex);
        }
        str="drop table record";
        stmt.executeUpdate(str);
        System.out.println("table record dropped successfully");
        
        str="drop table post";
        stmt.executeUpdate(str);
        System.out.println("table post dropped successfully");
        
        str="drop table comments";
        stmt.executeUpdate(str);
        System.out.println("table comments dropped successfully");
        
        str="drop table act";
        stmt.executeUpdate(str);
        System.out.println("table act dropped successfully");
        
        str="drop table postcom";
        stmt.executeUpdate(str);
        System.out.println("table postcom dropped successfully");
        
        str="drop table queries";
        stmt.executeUpdate(str);
        System.out.println("table queries dropped successfully");
        
        str="drop table newmessage";
        stmt.executeUpdate(str);
        System.out.println("table newmessage dropped successfully");
        
        
        str="drop table sentbox";
        stmt.executeUpdate(str);
        System.out.println("table sentbox dropped successfully");
        
        str="drop table inbox";
        stmt.executeUpdate(str);
        System.out.println("table inbox dropped successfully");
        
    }
    
    
}
