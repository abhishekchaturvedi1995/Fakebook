/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package logdem;

import connect.connectdb;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author hppc
 */
public class CreateTables {
    
    public static void main(String args[]) throws SQLException{
        Connection c=null;
        Statement stmt=null;
        String str="";
        try{
            c=connectdb.createconnection();
            stmt=c.createStatement();
        }
        catch(SQLException se){
            System.out.println("error"+se);
        }
        catch(ClassNotFoundException ex){
            System.out.println("found error......"+ex);
        }
        
        str="create table record(name varchar2(100) not null, dateofbirth varchar2(10) not null, gender varchar2(10) not null,"
                +" contactnumber number(15) not null, emailid varchar2(50) not null, "
                + "username varchar2(2000) primary key not null, password varchar2(2000) not null)";
        stmt.executeUpdate(str);
        System.out.println("table record created successfully");
        
        
        str="create table post(posts varchar2(4000), username varchar2(2000), likes number(3))";
        stmt.executeUpdate(str);
        System.out.println("table post created successfully");
       
        str="create table comments(post varchar2(4000), comm number(3), username varchar2(2000))";
        stmt.executeUpdate(str);
        System.out.println("table comments created successfully");
        
        str="create table act(username varchar2(2000), lkpost varchar2(4000))";
        stmt.executeUpdate(str);
        System.out.println("table act created successfully");
        
        str="create table postcom(post varchar2(4000), comm varchar2(4000), username varchar2(2000))";
        stmt.executeUpdate(str);
        System.out.println("table postcom created successfully");
        
        str="create table queries(q varchar2(4000), username varchar2(2000), response varchar2(4000))";
        stmt.executeUpdate(str);
        System.out.println("table queries created successfully");
        
        str="create table newmessage(message varchar2(4000), sender varchar2(2000), receiver varchar2(2000), inresponseto varchar2(4000))";
        stmt.executeUpdate(str);
        System.out.println("table newmessage created successfully");
        
        str="create table sentbox(message varchar2(4000), sender varchar2(2000), receiver varchar2(2000))";
        stmt.executeUpdate(str);
        System.out.println("table sentbox created successfully");
        
        str="create table inbox(message varchar2(4000), sender varchar2(2000), receiver varchar2(2000))";
        stmt.executeUpdate(str);
        System.out.println("table inbox created successfully");
        
        str="insert into act(username,lkpost) values(?,?)";
        PreparedStatement p=c.prepareStatement(str);
        p.setString(1,"-");
        p.setString(2, "-");
        p.executeUpdate();
        
        str="insert into newmessage(message, sender, receiver, inresponseto) values(?,?,?,?)";
        p=c.prepareStatement(str);
        p.setString(1,"-");
        p.setString(2, "-");
        p.setString(3, "-");
        p.setString(4, "-");
        p.executeUpdate();
        
        
        
    }
    
}
